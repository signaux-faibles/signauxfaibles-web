<template>
  <div>
    Page Non Trouvée<br/>
    <a href="/">Retour à l'écran de login</a>
  </div>
</template>